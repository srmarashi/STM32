#ifndef _WIRISH_CONSTANTS_H_
#define _WIRISH_CONSTANTS_H_

#ifdef __cplusplus
extern "C"{
#endif

enum BitOrder {
	LSBFIRST = 0,
	MSBFIRST = 1
};

#ifdef __cplusplus
}
#endif

#endif
